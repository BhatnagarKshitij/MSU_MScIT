/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question23;

/**
 *
 * @author Kshitij
 */
public class popcorn {
    public void taste(){
        System.out.println("Tasty!!!Popcorn");
    };
}
