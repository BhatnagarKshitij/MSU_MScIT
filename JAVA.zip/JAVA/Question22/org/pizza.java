package org;
import java.util.*;
public class pizza{

	
	public void displayMenu(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Pizza Options: 1. Magenta \n 2.Double Cheeze \n Olive Greens");
		
	}
	
}