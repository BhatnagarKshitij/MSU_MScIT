/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question25;

/**
 *
 * @author Kshitij
 */
public class Question25 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MP3Player product1=new MP3Player();
        TV Product2=new TV();
        product1.display();
        Product2.display();
    }
    
}
