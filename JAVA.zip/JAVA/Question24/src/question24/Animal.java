/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question24;

/**
 *
 * @author Kshitij
 */
public class Animal {
    static int no_of_leg=4;
    String animalName;
    public static class AquaticAnimals{
        public void display(){
            System.out.println("Fish has "+no_of_leg+" Legs");
        }
}
    
}
