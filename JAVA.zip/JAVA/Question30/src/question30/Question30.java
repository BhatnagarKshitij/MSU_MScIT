package question30;

/**
 *Write a program to sort the array of n integers in descending order. Include a try block to locate various exceptions related to array and catch them.
 * @author Kshitij
 */
public class Question30 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        sort s=new sort();
        s.getData();
        s.display();
    }
    
}
