/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question14;

/**
 *
 * @author Kshitij
 */
public class Question14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        BoxWeight item1 =new BoxWeight(10, 10, 10, 10);
    }
    
}
